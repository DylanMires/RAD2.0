
function pooling = convolution(filter, image)
big = size(image);
focusX = 1;
focusY = 1;
pooling = zeros(size(image));
while focusY ~= big(1)-1
 while focusX ~= big(1)-1
    filtration2 = filter.*image(focusX:focusX+2,focusY:focusY+2);
    scale = size(filtration2);
    pixelCount = scale(1)*scale(2);
    filterOutput = sum(sum(filtration2))/pixelCount; 
    pooling(focusX+1, focusY+1) = filterOutput;
    focusX = focusX + 1;
 end
focusX = 1;
focusY = focusY + 1;
end

    