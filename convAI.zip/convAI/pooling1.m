function storage = pooling1(image)
image = padarray(image, [1 1]);
big = size(image);
image(1,:) = [];
image(:,1) = [];
% disp(image)

storage = zeros(size(image));
c1 = 1;
c2 = 1;
while c2 < big(1)-1
while c1 < big(1)-1
window = image(c1:c1+1,c2:c2+1);
store = max(max(window));
storage(c1,c2) = store;
c1 = c1 + 2;
end
c1 = 1;
c2 = c2 + 2;
end
% disp(size(storage))
% disp(storage)

storage(6,:) = [];
storage(4,:) = [];
storage(2,:) = [];
% disp(storage)
storage(:,6) = [];
storage(:,4) = [];
storage(:,2) = [];
