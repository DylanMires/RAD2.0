
many broken things!


12 layer deep learning convolutional network that feeds to a single layer ANN. The ANN is a perceptron, with the ability to be made reccurent (good for us)

ANN is 7 input neurons, leading to 9 operating neurons, outputing to 2 neurons. 
18 Neurons
81 Synapses



This code diffreicniates an x shape from an o shape. WHile very limited in capacity, it 'can'* accomplish this task. Noticable problems include vanishing gradient, which can be resolved by implementing resNet features (layer skipping synapses)
