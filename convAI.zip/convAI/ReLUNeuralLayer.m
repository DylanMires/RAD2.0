function newSpace = ReLUNeuralLayer(oldSpace)

mask = (oldSpace > 0);
newSpace = mask .*oldSpace;