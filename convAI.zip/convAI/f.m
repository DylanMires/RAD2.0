function x = f(x) 
x = 1./(1+exp(-x));