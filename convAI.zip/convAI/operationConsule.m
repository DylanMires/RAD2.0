% for arduino, build a left-right AI

% where to load in augments?
% how to load in designed AI? 
%need to develop design and use flowchart

% maybe put in a learning system here to allow training of motor assemblys 

clear
clc
crashPrevent = 1;
while crashPrevent ~= -1
    file2 = input('To begin, please enter the file name ("example", NOT "exampleindex1.txt"): ', 's');
    if isfile([file2,'synIndex.txt'])&& isfile([file2,'neuIndex.txt'])
        W = readmatrix([file2,'synIndex.txt']);
        U = readmatrix([file2,'neuIndex.txt']);
               
        crashPrevent = -1;
    else
        disp('Files could not be located, please ensure that all files are present in the folder and try again')
    end
end

% arduino
% microphone
%internal

% runtimes, timed, never ending, once, variable dependent?



active = 1;

disp('select input')
while active ~= -1
    command = input('> ','s');
    if (command(1) == 'a')||(command(1) == 'A')
        % select pin and pin type ( input/output, motor, binary, pwm,
        % sonar)

    elseif (command(1) == 's')||(command(1) == 'S')


    elseif (command(1) == 'i')||(command(1) == 'I')


    end
end

