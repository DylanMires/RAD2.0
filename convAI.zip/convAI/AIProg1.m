function [W,U] = AIProg1(W, U, Classifications , Attributes, n, trainingIterations,splot,ffore)

n = 2.6; % can be removed later



m = 0; figure; hold on; e = size(Attributes); 
pH = [1; 1; 1; 1; 1; 1; 1; 1];
disp(e)

while m < trainingIterations 
    disp(m)
    m = m + 1;
    tic
    for i=1:e(1)
        disp(m)
        I = Attributes(i,:).'; 
        D = Classifications(i,:).';
        % recently modified---------------------
        if ffore == 0
        Ix1 = W*I*pH';
        rounder1 = size(Ix1);
        r = 1;
        rep = 0;
        Ix2 = zeros(rounder1(1),1);
        while r <= rounder1
            Ix2 = Ix2 + Ix1(:, r);
            r = r + 2;
            rep = rep + 1;
        end
        Ix2 = Ix2./ rep; % maybe this works?
        H = f(Ix2);
        
        
        else
        H = f(W*I);
        end
        % ---------------- recently modified ends
        O = f(U*H); 
        delta_i = O.*(1-O).*(D-O);
        delta_j = H.*(1-H).*(U.'*delta_i);
        U = U + n.*delta_i*(H.');
        W = W + n.*delta_j*(I.');
       
    end 

    if splot == 1
     RMS_Err = 0;
      for i=1:e(1)
          D = Classifications(i,:).';
           I = Attributes(i,:).';
           RMS_Err = RMS_Err + norm(D-f(U*f(W*I)),2);
      end
     y = RMS_Err/e(1);
     plot(m,log(y),'*');
    end
    toc
end

