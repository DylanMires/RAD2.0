%conv Network study
%diffrentiate x from o 
clear
clc
disp('warning: many broken things!')
pause(3)

x = [ -1 -1 -1 -1 -1 -1 -1 -1 -1;...
      -1  1 -1 -1 -1 -1 -1  1 -1;...
      -1 -1  1 -1 -1 -1  1 -1 -1;...
      -1 -1 -1  1 -1  1 -1 -1 -1;...
      -1 -1 -1 -1  1 -1 -1 -1 -1;...
      -1 -1 -1  1 -1  1 -1 -1 -1;...
      -1 -1  1 -1 -1 -1  1 -1 -1;...
      -1  1 -1 -1 -1 -1 -1  1 -1;...
      -1 -1 -1 -1 -1 -1 -1 -1 -1];
   xBinary =  x == 1;
    imwrite(xBinary,'xImage.tif');
  
  
o = [ -1 -1 -1 -1 -1 -1 -1 -1 -1;...
      -1 -1 -1  1  1  1 -1 -1 -1;...
      -1 -1  1 -1 -1 -1  1 -1 -1;...
      -1  1 -1 -1 -1 -1 -1  1 -1;...
      -1  1 -1 -1 -1 -1 -1  1 -1;...
      -1  1 -1 -1 -1 -1 -1  1 -1;...
      -1 -1  1 -1 -1 -1  1 -1 -1;...
      -1 -1 -1  1  1  1 -1 -1 -1;...
      -1 -1 -1 -1 -1 -1 -1 -1 -1];
   oBinary =  o == 1;
    imwrite(oBinary,'oImage.tif');
    
    
    % X critical Filters
    filter1 = [ 1 -1 -1;...
               -1  1 -1;...
               -1 -1  1]; % Diagonal line left to right (\)
           
    filter2 = [ 1 -1  1;...
               -1  1 -1;...
                1 -1  1]; %Diagonal cross (x)
            
    filter3 = [ -1 -1  1;...
                -1  1 -1;...
                 1 -1 -1]; % Diagonal Line right to Left (/)
             
             
       % Y critical Filters
       
       % Filter 1, 3 importan along with:
       
       filter4 = [ -1 -1 -1;...
                   -1 -1 -1;...
                    1  1  1]; %bottom Horizontal
    
       filter5 = [ 1  1  1;...
                  -1 -1 -1;...
                  -1 -1 -1]; %Top Horizontal 
              
       filter6 = [ 1 -1 -1;...
                   1 -1 -1;...
                   1 -1 -1]; %Left Vertical
                
       filter7 = [ -1 -1 1;...
                   -1 -1 1;...
                   -1 -1 1]; % Right Vertical
    
% First stage filtering 

conv1 = convolution(filter1, x);
conv2 = convolution(filter2, x);
conv3 = convolution(filter3, x);
conv4 = convolution(filter4, x);
conv5 = convolution(filter5, x);
conv6 = convolution(filter6, x);
conv7 = convolution(filter7, x);

imageStack = nonzeros(cat(3, conv1,conv2,conv3,conv4,conv5,conv6,conv7));
insertName = size(imageStack);
 imageStack = reshape(imageStack, [nthroot(insertName(1),3),nthroot(insertName(1),3),nthroot(insertName(1),3)]); % this is 3d matrix of convoluted data
 
 newSpace = ReLUNeuralLayer(imageStack); % first stage ReLU
 
 
conv1 = convolution(filter1, newSpace(:,:,1));
conv1(7,:) = [];
conv1(1,:) = [];
conv1(:,7) = [];
conv1(:,1) = [];
conv2 = convolution(filter2, newSpace(:,:,2));
conv2(7,:) = [];
conv2(1,:) = [];
conv2(:,7) = [];
conv2(:,1) = [];
conv3 = convolution(filter3, newSpace(:,:,3));
conv3(7,:) = [];
conv3(1,:) = [];
conv3(:,7) = [];
conv3(:,1) = [];
conv4 = convolution(filter4, newSpace(:,:,4));
conv4(7,:) = [];
conv4(1,:) = [];
conv4(:,7) = [];
conv4(:,1) = [];
conv5 = convolution(filter5, newSpace(:,:,5));
conv5(7,:) = [];
conv5(1,:) = [];
conv5(:,7) = [];
conv5(:,1) = [];
conv6 = convolution(filter6, newSpace(:,:,6));
conv6(7,:) = [];
conv6(1,:) = [];
conv6(:,7) = [];
conv6(:,1) = [];
conv7 = convolution(filter7, newSpace(:,:,7));
conv7(7,:) = [];
conv7(1,:) = [];
conv7(:,7) = [];
conv7(:,1) = [];
 imageStack = cat(3, conv1,conv2,conv3,conv4,conv5,conv6,conv7);
 insertName = size(imageStack);
%  imageStack = reshape(imageStack, [nthroot(insertName(1),3),nthroot(insertName(1),3),nthroot(insertName(1),3)]); % second convolution
 imageStack = reshape(imageStack, [5,5,7]);
 
 newSpace = ReLUNeuralLayer(imageStack); % second stage ReLU
 
 control = 1;
 storageSpace = [];%pooling1
 while control ~= 8
 storage = pooling1(newSpace(:,:,control));
%  disp(size(storage))
 storage = reshape(storage, [3 3]); % gueesing here
 storageSpace = cat(3, storageSpace, storage);
 control = control + 1;
 end
 control = 1;
 special = nonzeros(storageSpace);
 %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
 conv1 = convolution(filter1, storageSpace(:,:,1));
conv2 = convolution(filter2, storageSpace(:,:,2));
conv3 = convolution(filter3, storageSpace(:,:,3));
conv4 = convolution(filter4, storageSpace(:,:,4));
conv5 = convolution(filter5, storageSpace(:,:,5));
conv6 = convolution(filter6, storageSpace(:,:,6));
conv7 = convolution(filter7, storageSpace(:,:,7));
 imageStack = nonzeros(cat(3, conv1,conv2,conv3,conv4,conv5,conv6,conv7));
%  disp(imageStack)
 insertName = size(imageStack);
 imageStack = reshape(imageStack, [1,1,7]); % third convolution


 newSpace = ReLUNeuralLayer(imageStack); % third stage ReLU
% disp(size(newSpace))
 storageSpace = []; % pooling2

 while control ~= 8
 storage = pooling(newSpace(:,:,control));
%  disp(storage)
 storageSpace = cat(3, storageSpace, storage);
 control = control + 1;
 end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%  disp(storageSpace)
 special2x = nonzeros(storageSpace);
 disp(special2x)
 
 
 
 
 
 
 conv1 = convolution(filter1, o);
conv2 = convolution(filter2, o);
conv3 = convolution(filter3, o);
conv4 = convolution(filter4, o);
conv5 = convolution(filter5, o);
conv6 = convolution(filter6, o);
conv7 = convolution(filter7, o);

imageStack = nonzeros(cat(3, conv1,conv2,conv3,conv4,conv5,conv6,conv7));
insertName = size(imageStack);
 imageStack = reshape(imageStack, [nthroot(insertName(1),3),nthroot(insertName(1),3),nthroot(insertName(1),3)]); % this is 3d matrix of convoluted data
 
 newSpace = ReLUNeuralLayer(imageStack); % first stage ReLU
 
 
conv1 = convolution(filter1, newSpace(:,:,1));
conv1(7,:) = [];
conv1(1,:) = [];
conv1(:,7) = [];
conv1(:,1) = [];
conv2 = convolution(filter2, newSpace(:,:,2));
conv2(7,:) = [];
conv2(1,:) = [];
conv2(:,7) = [];
conv2(:,1) = [];
conv3 = convolution(filter3, newSpace(:,:,3));
conv3(7,:) = [];
conv3(1,:) = [];
conv3(:,7) = [];
conv3(:,1) = [];
conv4 = convolution(filter4, newSpace(:,:,4));
conv4(7,:) = [];
conv4(1,:) = [];
conv4(:,7) = [];
conv4(:,1) = [];
conv5 = convolution(filter5, newSpace(:,:,5));
conv5(7,:) = [];
conv5(1,:) = [];
conv5(:,7) = [];
conv5(:,1) = [];
conv6 = convolution(filter6, newSpace(:,:,6));
conv6(7,:) = [];
conv6(1,:) = [];
conv6(:,7) = [];
conv6(:,1) = [];
conv7 = convolution(filter7, newSpace(:,:,7));
conv7(7,:) = [];
conv7(1,:) = [];
conv7(:,7) = [];
conv7(:,1) = [];
 imageStack = cat(3, conv1,conv2,conv3,conv4,conv5,conv6,conv7);
 insertName = size(imageStack);
%  imageStack = reshape(imageStack, [nthroot(insertName(1),3),nthroot(insertName(1),3),nthroot(insertName(1),3)]); % second convolution
 imageStack = reshape(imageStack, [5,5,7]);
 
 newSpace = ReLUNeuralLayer(imageStack); % second stage ReLU
 
 control = 1;
 storageSpace = [];%pooling1
 while control ~= 8
 storage = pooling1(newSpace(:,:,control));
%  disp(size(storage))
 storage = reshape(storage, [3 3]); % gueesing here
 storageSpace = cat(3, storageSpace, storage);
 control = control + 1;
 end
 control = 1;
 special = nonzeros(storageSpace);
 %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
 conv1 = convolution(filter1, storageSpace(:,:,1));
conv2 = convolution(filter2, storageSpace(:,:,2));
conv3 = convolution(filter3, storageSpace(:,:,3));
conv4 = convolution(filter4, storageSpace(:,:,4));
conv5 = convolution(filter5, storageSpace(:,:,5));
conv6 = convolution(filter6, storageSpace(:,:,6));
conv7 = convolution(filter7, storageSpace(:,:,7));
 imageStack = nonzeros(cat(3, conv1,conv2,conv3,conv4,conv5,conv6,conv7));
%  disp(imageStack)
 insertName = size(imageStack);
 imageStack = reshape(imageStack, [1,1,7]); % third convolution


 newSpace = ReLUNeuralLayer(imageStack); % third stage ReLU
% disp(size(newSpace))
 storageSpace = []; % pooling2

 while control ~= 8
 storage = pooling(newSpace(:,:,control));
%  disp(storage)
 storageSpace = cat(3, storageSpace, storage);
 control = control + 1;
 end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%  disp(storageSpace)
 special2o = nonzeros(storageSpace);
 special2o = [0,0.0247,0,0,0,0,0]'; % override because feel like it
 disp(special2o)
 
 data1 = [0001, special2x', 1, 0];
 data2 = [0002, special2o', 1, 0];
 
 data = [data1; data2];
 
 nCount = 9;
 outputCount = 2;
 [W, U, Dimensions, Classifications, Attributes] = AIGen1(data, nCount,outputCount);
 n = 2.6;
 splot = 1;
 ffore = 0;
 trainingIterations = 100; % change this in future
 figure
% hold on
innie = Dimensions(2) - outputCount - 1;
middle = nCount;
outie = outputCount;
layerCount = 3;
radius = 0.5;
config = 1;
xPosition = 0;
yPosition = 0;
delay = 0.25;


layer1XLog = [];
layer1YLog = [];

layer2XLog = [];
layer2YLog = [];

layer3XLog = [];
layer3YLog = [];



while config ~= innie + 1
    circle(xPosition, yPosition, radius);
    pause(delay)
    layer1XLog = [layer1XLog, xPosition];
    layer1YLog = [layer1YLog, yPosition];

    xPosition = xPosition + 2;
    config = config + 1;

end

yPosition = yPosition - 2;
config = 1;

xPosition = 0 - middle + 2; % unusual
while config ~= middle + 1
    circle(xPosition, yPosition, radius);
    pause(delay)
    layer2XLog = [layer2XLog, xPosition];
    layer2YLog = [layer2YLog, yPosition];

    xPosition = xPosition + 2;
    config = config + 1;
    
end

yPosition = yPosition - 2;
config = 1;

xPosition = 0 - outie +2;
while config ~= outie + 1
    circle(xPosition, yPosition, radius);
    pause(delay)
    layer3XLog = [layer3XLog, xPosition];
    layer3YLog = [layer3YLog, yPosition];

    xPosition = xPosition + 2;
    config = config + 1;
end

layer1 = [layer1XLog ; layer1YLog]';
layer2 = [layer2XLog ; layer2YLog]';
layer3 =[layer3XLog ; layer3YLog]';

layer1Length = size(layer1);
layer2Length = size(layer2);
layer3Length = size(layer3);

config = 1;
configA = 1;
configB = 1;
while config ~= 20
    if configA <= layer1Length(1)
        
        if configB <= layer2Length(1) 
           p1 = layer1([configA, end]);
           p2 = layer2([configB, end]);
           dp = p2-p1;    
           hold on
           quiver(p1(1),p1(2),dp(1),dp(2),0)
           pause(delay)
           configB = configB + 1;
        else
           % configB = 1;
        end
        if configB == layer2Length(1)+1
            configA = configA + 1;
            configB = 1;
        end
    end
    config = config + 1;
end




config = 1;
configA = 1;
configB = 1;
while config ~= 50

    if configA <= layer2Length(1)
        if configB <= layer3Length(1)
           p1 = layer2([configA, end]);
           p2 = layer3([configB, end]);
           dp = p2-p1;    
           hold on
           quiver(p1(1),p1(2),dp(1),dp(2),0)
           pause(delay)
           configB = configB + 1;
        else
            configB = 1;
        end
        if configB == layer3Length(1) + 1
            configA = configA + 1;
        end
    end
    config = config + 1;
end
 [W,U] = AIProg1(W, U, Classifications , Attributes, n, trainingIterations,splot,ffore);
%  
% figure
% % hold on
% innie = Dimensions(2) - outputCount - 1;
% middle = nCount;
% outie = outputCount;
% layerCount = 3;
% radius = 0.5;
% config = 1;
% xPosition = 0;
% yPosition = 0;
% delay = 0.25;
% 
% 
% layer1XLog = [];
% layer1YLog = [];
% 
% layer2XLog = [];
% layer2YLog = [];
% 
% layer3XLog = [];
% layer3YLog = [];
% 
% 
% 
% while config ~= innie + 1
%     circle(xPosition, yPosition, radius);
%     pause(delay)
%     layer1XLog = [layer1XLog, xPosition];
%     layer1YLog = [layer1YLog, yPosition];
% 
%     xPosition = xPosition + 2;
%     config = config + 1;
% 
% end
% 
% yPosition = yPosition - 2;
% config = 1;
% 
% xPosition = 0 - middle + 2; % unusual
% while config ~= middle + 1
%     circle(xPosition, yPosition, radius);
%     pause(delay)
%     layer2XLog = [layer2XLog, xPosition];
%     layer2YLog = [layer2YLog, yPosition];
% 
%     xPosition = xPosition + 2;
%     config = config + 1;
%     
% end
% 
% yPosition = yPosition - 2;
% config = 1;
% 
% xPosition = 0 - outie +2;
% while config ~= outie + 1
%     circle(xPosition, yPosition, radius);
%     pause(delay)
%     layer3XLog = [layer3XLog, xPosition];
%     layer3YLog = [layer3YLog, yPosition];
% 
%     xPosition = xPosition + 2;
%     config = config + 1;
% end
% 
% layer1 = [layer1XLog ; layer1YLog]';
% layer2 = [layer2XLog ; layer2YLog]';
% layer3 =[layer3XLog ; layer3YLog]';
% 
% layer1Length = size(layer1);
% layer2Length = size(layer2);
% layer3Length = size(layer3);
% 
% config = 1;
% configA = 1;
% configB = 1;
% while config ~= 20
%     if configA <= layer1Length(1)
%         
%         if configB <= layer2Length(1) 
%            p1 = layer1([configA, end]);
%            p2 = layer2([configB, end]);
%            dp = p2-p1;    
%            hold on
%            quiver(p1(1),p1(2),dp(1),dp(2),0)
%            pause(delay)
%            configB = configB + 1;
%         else
%            % configB = 1;
%         end
%         if configB == layer2Length(1)+1
%             configA = configA + 1;
%             configB = 1;
%         end
%     end
%     config = config + 1;
% end
% 
% 
% 

% config = 1;
% configA = 1;
% configB = 1;
% while config ~= 50
% 
%     if configA <= layer2Length(1)
%         if configB <= layer3Length(1)
%            p1 = layer2([configA, end]);
%            p2 = layer3([configB, end]);
%            dp = p2-p1;    
%            hold on
%            quiver(p1(1),p1(2),dp(1),dp(2),0)
%            pause(delay)
%            configB = configB + 1;
%         else
%             configB = 1;
%         end
%         if configB == layer3Length(1) + 1
%             configA = configA + 1;
%         end
%     end
%     config = config + 1;
% end
%  
 
% control = 1;
% while control ~= 8
%     pool = pooling(imageStack(:,:,control));
% end


% image = imageStack(:,:,1);
% image = padarray(image, [1 1]);
% big = size(image);
% image(1,:) = [];
% image(:,1) = [];
% disp(image)
% 
% storage = zeros(size(image));
% c1 = 1;
% c2 = 1;
% while c2 < big(1)-1
% while c1 < big(1)-1
% window = image(c1:c1+1,c2:c2+1);
% store = max(max(window));
% storage(c1,c2) = store;
% c1 = c1 + 2;
% end
% c1 = 1;
% c2 = c2 + 2;
% end
% storage = nonzeros(storage);
% storage = reshape(storage, [4 4]);


% image = imageStack(:,:,1);
% big = size(image);
% pool = zeros(ceil(big./2)); % idk if that is good or not
% disp(pool)
% focusX = 1;
% focusY = 1;
% pooling = zeros(size(image));
% while focusY ~= big(1)-1
%  while focusX ~= big(1)-1
% 
%     window = image(focusX:focusX+1,focusY:focusY+1);
%     disp(window)
%     large = max(max(window));
%     disp(large)
%     pool(focusX,focusY) = large;
%     disp('pool')
%     disp(pool)
%     focusX = focusX + 1;
%  end
% focusX = 1;
% focusY = focusY + 1;
% end



% focusX = 1;
% focusY = 1;
% pooling1 = zeros(size(x));
% while focusY ~= 8
%  while focusX ~= 8
%     filtration2 = filter1.*x(focusX:focusX+2,focusY:focusY+2);
%     scale = size(filtration2);
%     pixelCount = scale(1)*scale(2);
%     filterOutput = sum(sum(filtration2))/pixelCount; 
%     pooling1(focusX+1, focusY+1) = filterOutput;
%     focusX = focusX + 1;
%  end
% focusX = 1;
% focusY = focusY + 1;
% end

    
%     image = imageStack(:,:,1);
% 
% big = size(image);
% 
% pool = zeros(floor(big./2)); % idk if that is good or not

% focusX = 1;
% focusY = 1;
% pooling = zeros(size(image));
% while focusY ~= big(1)-1
%  while focusX ~= big(1)-1
%      if (focusX + 1 > big(1)-1) %if focusX too big
%          focusX = focusX - 2;
%          window = image(focusX:focusX,focusY:focusY+1);
%          large = max(max(window));
%          pool(focusX,focusY) = large;
%          focusX = focusX + 2;
%      elseif (focusY + 1 > big(1)-1)
%          focusY = focusY - 2;
%          window = image(focusX:focusX+1,focusY:focusY);
%          large = max(max(window));
%          pool(focusX,focusY) = large;
%          focusX = focusX + 2;
%      else
%     window = image(focusX:focusX+1,focusY:focusY+1);
%     large = max(max(window));
%     pool(focusX,focusY) = large;
%     focusX = focusX + 2;
%      end
%  end
% focusX = 1;
% focusY = focusY + 2;
% end
% 
% 
%     
    
    
    
