% AI Generator


function [W, U, Dimensions, Classifications, Attributes] = AIGen1(RAW_DATA, nbrOfNodes,outPuts)



Dimensions = size(RAW_DATA);
Classifications = RAW_DATA(:,(Dimensions(2)-outPuts):Dimensions(2));
Attributes = [];

for i=2:Dimensions(2)-outPuts
    Attributes = [Attributes RAW_DATA(:,i)];
end



W = rand(nbrOfNodes, length(Attributes(1,:))); 
U = rand(length(Classifications(1,:)),nbrOfNodes);

